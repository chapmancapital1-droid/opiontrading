# OptionScope — Simplified Option View

This prototype reduces the new-options-trade workflow to three user decisions:

1. **Market outlook:** bullish, bearish, sideways, or expecting a large move.
2. **Timeframe:** this week, two to four weeks, or one to three months.
3. **Maximum loss:** a dollar risk budget.

The interface then presents three transparent, defined-risk trade candidates. Each candidate shows only the data needed for a first comparison: entry debit or credit, maximum loss, maximum profit, breakeven, expiration/DTE, and clear match reasons. The selected trade opens in a fixed review ticket with a plain-English outcome, P/L graph, quantity and limit controls, probability estimate, liquidity context, warnings, and an optional advanced-Greeks section.

## Recommended hierarchy

### Always visible

- Ticker, underlying price/change, market status, and quote timestamp
- Upcoming earnings or other material catalyst before expiration
- Implied-volatility context and expected move for the selected expiration
- Direction, timeframe, and maximum-risk controls
- Strategy and legs
- Expiration and DTE
- Debit/credit and bid/ask context
- Max loss, max profit, and breakeven
- Quantity, limit price, and total debit/credit
- Buying-power impact
- Risk alerts

### Visible in candidate comparison

- Liquidity status based on bid/ask width, volume, and open interest
- Model-estimated probability of profit, labeled as an estimate
- A short explanation of why the candidate matches the user's inputs

### Collapsed by default

- Delta, theta, vega, gamma, and strategy-level IV
- Per-leg bid, ask, volume, open interest, and Greeks
- Full simulated-return surface
- Full option chain
- Exercise/assignment and settlement details, unless a risk alert makes them immediately relevant

## Required data groups

### Underlying market data

- Symbol, security name, asset type
- Last price, absolute and percentage change
- Bid/ask, market status, quote timestamp, data-delay status
- Intraday and historical OHLC data
- Earnings date/time, ex-dividend date, splits, and other corporate actions
- Historical and implied-volatility series
- Expected move for each expiration

### Option contract data

- Contract identifier/root, call or put, strike, expiration, DTE
- Bid, ask, last, midpoint/mark, quote timestamp
- Volume, open interest, bid/ask spread percentage
- Implied volatility, delta, gamma, theta, vega, rho
- Contract multiplier, exercise style, settlement style, expiration session
- In/out-of-the-money amount and intrinsic/extrinsic value

### Strategy calculations

- Legs and side for every leg
- Net debit/credit and strategy bid/ask
- Maximum gain, maximum loss, breakeven point(s)
- Reward/risk ratio and buying-power effect
- Probability estimate plus model name, assumptions, and timestamp
- P/L at expiration and simulated P/L before expiration
- Net Greeks

### User/account context

- Options approval level and permitted strategies
- Account type, buying power, margin/cash restrictions
- Existing positions and open orders in the ticker
- User-selected maximum risk and portfolio concentration limit
- Day-trade and expiration-day restrictions where applicable

### Risk and data-quality flags

- Earnings before expiration
- Ex-dividend/early-assignment exposure for short options
- 0DTE/high-gamma exposure
- Wide spread, low volume/open interest, or no valid market
- Stale or delayed quote
- Max loss above budget
- Buying-power shortfall
- Pin/expiration and after-hours gap risk
- Undefined-risk or naked-short exposure

## Product principle

The simplified screen should help the trader make one decision, not display every available data point. Keep the full chain, detailed Greeks, and simulation tools one tap away, but do not place them in the primary decision path.

All values in the HTML prototype are illustrative.
